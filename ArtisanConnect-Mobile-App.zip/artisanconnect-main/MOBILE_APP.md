# ArtisanConnect — Android Mobile App

This project is now **React + Tailwind + Capacitor**, not Vite.

## What changed
- Removed Vite and `vite.config.js`.
- Switched the React build to `react-scripts`.
- Added Capacitor Android configuration.
- Added a portrait/mobile app viewport and standalone mobile metadata.
- Kept the existing ArtisanConnect screens, demo mode, Hindi/English toggle, verification flow, cataloging flow and storefront.

## Run on Android
1. Install Node.js 20+ and Android Studio.
2. In this folder run:
   ```bash
   npm install
   npx cap add android
   npm run android
   ```
3. In Android Studio, select an emulator or connected phone and press Run.

## Build an APK
```bash
npm install
npx cap add android
npm run cap:sync
cd android
./gradlew assembleDebug
```

On Windows use `gradlew.bat assembleDebug`.
The debug APK will be under `android/app/build/outputs/apk/debug/`.
